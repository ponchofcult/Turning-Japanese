from lib.compatibility import register_module

register_module("concurrent.futures", "script.module.futures")
