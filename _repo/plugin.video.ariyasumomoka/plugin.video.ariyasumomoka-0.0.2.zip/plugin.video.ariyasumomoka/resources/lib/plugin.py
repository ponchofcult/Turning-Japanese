# -*- coding: utf-8 -*-

from __future__ import unicode_literals

# noinspection PyUnresolvedReferences
from codequick import Route, Resolver, Listitem, utils, run
from codequick.utils import urljoin_partial, bold
import urlquick
import xbmcgui
import re
import resolveurl
import xbmc
import urllib



headers = {
    "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36"
}
URL = "https://www.ariyasumomoka.jp"
LOGIN_ROUTE = ""


@Route.register
def root(plugin, content_type="segment"):
    item = Listitem()
    item.label = "PHOTOGRAPHY"
    linkpart = "/photography/"
    url = URL + linkpart
    if item.label == "MOVIE":
        item.set_callback(get_videos, url=url)  
    elif item.label == "PHOTOGRAPHY":
        item.set_callback(get_photos, url=url)
    else:
        item.set_callback(get_albums, url=url)  
    yield item
        
    item = Listitem()
    item.label = "MOVIE"
    linkpart = "/movie/"
    url = URL + linkpart
    if item.label == "MOVIE":
        item.set_callback(get_videos, url=url)  
    elif item.label == "PHOTOGRAPHY":
        item.set_callback(get_photos, url=url)
    else:
        item.set_callback(get_albums, url=url)  
    yield item
        
    item = Listitem()
    item.label = "DISCOGRAPHY"
    linkpart = "/discography/"
    url = URL + linkpart
    if item.label == "MOVIE":
        item.set_callback(get_videos, url=url)  
    elif item.label == "PHOTOGRAPHY":
        item.set_callback(get_photos, url=url)
    else:
        item.set_callback(get_albums, url=url)  
    yield item
   
        
@Route.register
def get_videos(plugin, url):
    resp = urlquick.get(url, headers=headers, max_age=-1)
    videosRoot = resp.parse("ul", attrs={"class": "movie-index"})
    videoslist = videosRoot.iterfind("li/a")

    for elem in videoslist:
        item = Listitem()
        item.label = elem.find("div").text
        linkpart = elem.get("href")
        url = URL + "/movie/" + linkpart
        img = elem.find("figure/img").get("src")
        item.art["thumb"] = URL + img
        item.art["fanart"] = URL + img
        item.set_callback(play_Video, url=url)
        yield item
        
        
@Route.register
def get_photos(plugin, url):
    resp = urlquick.get(url, headers=headers, max_age=-1)
    videosRoot = resp.parse("ul", attrs={"class": "bio__content-list"})
    videoslist = videosRoot.iterfind("li/img")
    
    counter = 1
    for elem in videoslist:
        item = Listitem()
        item.label = "IMAGE " + str(counter)
        linkpart = elem.get("src")
        url = URL + linkpart
        img = elem.get("src")
        item.art["thumb"] = URL + img
        item.art["fanart"] = URL + img
        item.set_callback(show_Photos, url=url)
        counter += 1
        yield item


@Resolver.register
def play_Video(plugin,url):
    headers = {"User-Agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.90 Safari/537.36"}
    resp = urlquick.get(url, headers=headers, max_age=-1)
    pageRoot = resp.parse("div",attrs={"class":"wrap"})
    pageElems = pageRoot.iterfind("div")
    
    for elem in pageElems:
        url = elem.find("div/div/iframe").get("src")
        # url = url
        resolved = resolveurl.resolve(url)
        return resolved


@Resolver.register
def show_Photos(plugin,url):
    url = url
    xbmc.executebuiltin("ShowPicture(" + url +")")
    plugin = plugin.extract_source(url)
    return Listitem().from_dict(**{
        "label" : "Showing",
        "callback" : plugin,
    })


@Route.register
def get_albums(plugin,url):
    resp = urlquick.get(url, headers=headers, max_age=-1)
    albumsRoot = resp.parse("div", attrs={"class": "wrap"})
    albumslist = albumsRoot.iterfind("ul")
    allAlbumsUrl = url

    for elem in albumslist:
        item = Listitem()
        item.label = elem.find("li/span").text
        url = allAlbumsUrl
        item.set_callback(albums_List, url=url)
        yield item
        
        item = Listitem()
        item.label = elem.find("li/a").text
        linkpart = elem.find("li/a").get("href")
        url = URL + linkpart
        item.set_callback(albums_List, url=url)
        yield item
        
        item = Listitem()
        item.label = elem.find("li[3]/a").text
        linkpart = elem.find("li[3]/a").get("href")
        url = URL + linkpart
        item.set_callback(albums_List, url=url)
        yield item
        
        item = Listitem()
        item.label = elem.find("li[4]/a").text
        linkpart = elem.find("li[4]/a").get("href")
        url = URL + linkpart
        item.set_callback(albums_List, url=url)
        yield item
        
        item = Listitem()
        item.label = elem.find("li[5]/a").text
        linkpart = elem.find("li[5]/a").get("href")
        url = URL + linkpart
        item.set_callback(albums_List, url=url)
        yield item
        
        item = Listitem()
        item.label = elem.find("li[6]/a").text
        linkpart = elem.find("li[6]/a").get("href")
        url = URL + linkpart
        item.set_callback(albums_List, url=url)
        yield item
        
        
@Route.register
def albums_List(plugin, url):
    resp = urlquick.get(url, headers=headers, max_age=-1)
    albumsRoot = resp.parse("div", attrs={"class": "disco-index__list"})
    albumslist = albumsRoot.iterfind("ul/li/a")
    
    for album in albumslist:
        item = Listitem()
        item.label = album.find("div[2]").text
        linkpart = album.get("href").replace('.','/discography/')
        url = URL + linkpart
        img = album.find("figure/img").get("src")
        item.art["thumb"] = URL + img
        item.art["fanart"] = URL + img
        item.set_callback(album_Page, url=url)
        yield item
        
        
@Route.register
def album_Page(plugin, url):
    resp = urlquick.get(url, headers=headers, max_age=-1)
    albumRoot = resp.parse("div", attrs={"class": "wrap"})
    albumElems = albumRoot.iterfind("div/div")
    
    for elem in albumElems:
        item = Listitem()
        item.label = elem.find("div[2]/h3").text
        url = elem.find("div[2]/div[3]/a[2]").get("href")
        img = elem.find("div/div/div/img").get("src")
        item.art["thumb"] = URL + img
        item.art["fanart"] = URL + img
        if item.label == "有安杏果 Pop Step Zepp Tour 2019":
            item.set_callback(enter_AlbumPopSZT2019, url=url)
        else:
            item.set_callback(enter_AlbumVideo, url=url)
    
        yield item
        
        
@Route.register
def enter_AlbumVideo(plugin, url):
    resp = urlquick.get(url, headers=headers, max_age=-1)
    videosRoot = resp.parse("section", attrs={"class": "section section--v1"})
    videosElems = videosRoot.iterfind("div/div/div/div/div/iframe")
    
    counter = 1
    for elem in videosElems:
        item = Listitem()
        item.label = "PLAY VIDEO " + str(counter)
        url = elem.get("src")
        item.set_callback(play_AlbumVideo, url=url)
        counter += 1
        yield item        
        
            
@Route.register
def enter_AlbumPopSZT2019(plugin, url):
    resp = urlquick.get(url, headers=headers, max_age=-1)
    videosRoot = resp.parse("div", attrs={"class": "movie"})
    videosElems = videosRoot.iterfind("div/div/div/iframe")
    
    counter = 1
    for elem in videosElems:
        item = Listitem()
        item.label = "PLAY VIDEO " + str(counter)
        url = elem.get("src")
        item.set_callback(play_AlbumVideo, url=url)
        counter += 1
        yield item
        

@Resolver.register
def play_AlbumVideo(plugin,url):
    url = url
    resolved = resolveurl.resolve(url)
    return resolved
